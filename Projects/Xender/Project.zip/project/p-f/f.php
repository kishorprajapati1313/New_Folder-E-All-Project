
<section class="image5 ">
    <div class="image7 text">
    <ul>
        <li>
            <a href="wcwkjw"><img  src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
        </li>
        <li>
            <a href="kp.html"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
        </li>
        <li>
            <a href="wcwkjw.html"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
        </li>
    </ul>
</div>
</section>


<section class="image6">
    <div class="image7 text">
    <p> All right teserver by kp  <a href="oji.html">kp</a>
         
    </p>
</div>
</section> 

</body>
</html>