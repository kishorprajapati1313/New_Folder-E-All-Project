<?php include("config/co.php");  ?>


<!doctype html>
<html lang="en">   <!-- lang==language and en==english -->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="'width-device-width, initial-scale=1.0">
        <title> project</title>
    <link rel="stylesheet" href="css/kp.css" >
</head>
<body>


<section class="image">
    <div class="image7">
        <div class="logo">
            <img src="images/12.jpg" alt="bvuebv" hight="10%" width="99%" class='i'>
            </div>
        <div class="menu align ">
            <ul>
                <li>
                    <a href="<?php echo SIT; ?>" class="a">Home</a>
                </li>
                <li>
                    <a href="<?php echo SIT; ?>c.php">Category</a>
                </li>
                <li>
                    <a href="<?php echo SIT; ?>b.php">Book</a>
                </li>
                <li>
                    <a href="#">Contect</a>
                </li>

            </ul>
        </div>
        <div class="clear">
            </div>
    </div>
</section>