<?php 
    include("../config/co.php");    
    include('l-c.php');
?>


<html>
    <head>
        <title>book order website- home page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
    
    
    <div class="menu text">
        <div class="wrapper">
        <ul>
            <li><a href='index.php'>Home</a></li>
            <li><a href='manage-admin.php'>Admin </a></li>
            <li><a href='m-c.php'>category</a></li>
            <li><a href='m-b.php'>book</a></li>
            <li><a href='m-o.php'>order</a></li>
            <li><a href='logout.php'>Logout</a></li>

        </ul>
        </div>
     </div>   