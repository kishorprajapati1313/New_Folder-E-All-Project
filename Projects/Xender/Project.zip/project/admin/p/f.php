<div class="foot">
    <div class="wrapper ">

    <p class="text">2022-23 all right reserved, some author, Developed By - <a href="#">Kishor Prajapati</a></p>
        </div>
        </div>   

</body>
</html>