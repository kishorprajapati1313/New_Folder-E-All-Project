<?php include('Par/menu.php')  ?>

       </div>
   </section>
    
   <section class="second-part">
    <div class="cont part-1">
       <div class="center">
            <form action="part.html" method="post" class='sp'>
                <input type="text" name="search" class="var space">
                <input type="submit" name="submit" value="search" class="btn space">
            </form>
       </div>
   </div>
   </section>

   <section class="third-part">
    <div class="cont part-2">  
                <div>
                    <img src="images/tree.jpg" class="img">
                </div>
   </div>
   </section>

   <section class="fourth-part">
    <div class="cont">
        <h4 class="center" ><font size="10px">Exploar Proudct</font></h1> 
    </div>
    <div class="number">
        <div class="frame">

            <p class="text-main"> Smart watch  </p>
            <p class="text">  20% off </p><br>
            <img src="images/land.jpg" class="cover"><br>
            <a href="#">see more</a>
        </div>


        <div class="frame">

            <p class="text-main"> Smart watch  </p>
            <p class="text">  20% off </p><br>
            <img src="images/land.jpg" class="cover"><br>
            <a href="#">see more</a>
        </div>


        <div class="frame">

            <p class="text-main"> Smart watch  </p>
            <p class="text">  20% off </p><br>
            <img src="images/land.jpg" class="cover"><br>
            <a href="#">see more</a>
        </div>


        <div class="frame">

            <p class="text-main"> Smart watch  </p>
            <p class="text">  20% off </p><br>
            <img src="images/land.jpg" class="cover"><br>
            <a href="#">see more</a>
        </div>

    </div>
   </section>

   <?php include('Par/footer.php')  ?>