<section class="last-part">
    <div class="center">
        All right to serve by <a href="#">BOYS</a>
    </div>
   </section>

</body>
</html>