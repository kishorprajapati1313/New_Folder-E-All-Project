document.addEventListener("DOMContentLoaded", function() {
  const addToCartButtons = document.querySelectorAll(".product button");
  const cartItemsContainer = document.getElementById("cart-items");
  const checkoutButton = document.getElementById("checkout");

  addToCartButtons.forEach(function(button) {
    button.addEventListener("click", function() {
      const productName = button.parentNode.querySelector("h3").textContent;
      const cartItem = document.createElement("div");
      cartItem.textContent = productName;
      cartItemsContainer.appendChild(cartItem);
    });
  });

  checkoutButton.addEventListener("click", function() {
    alert("Checkout functionality will be implemented later.");
  });
});
