<?php include('../ad-par/menu.php');  ?> 

<section class="main">
    <h1>Add Section</h1><br>
    <?php
    if(isset($_SESSION['upload'])){
        echo $_SESSION['upload'];
        unset($_SESSION['upload']);
    }
    ?><br>

    <form action="" method='POST' enctype="multipart/form-data">
        <table class="tbl-30">
            <tr>
                <td>Name:</td>
                <td><input type='text' name='name'></td>
            </tr>

            <tr>
                <td>Select Image:</td>
                <td><input type='file' name='image'></td>
            </tr>

            <tr>
                <td>Fectured:</td>
                <td><input type='radio' name='fectured' value='yes'>yes <input type='radio' name='fectured' value='no'>no</td>
            </tr>

            <tr>
                <td>Active:</td>
                <td><input type='radio' name='active' value='yes'>yes <input type='radio' name='active' value='no'>no</td>
            </tr>

            <tr>
                <td colspan='2'>
                    <input type='submit' name='submit' value='Add Section' class='btn-s'></td>
            </tr>

        </table>
    </form>
</section>

<?php include('../ad-par/footer.php');  ?> 

<?php 

    if(isset($_POST['submit'])){
       
        $name = $_POST['name'];

        if(isset($_FILES['image']['name'])){
            $image_name = $_FILES['image']['name'];

              //image selected or not
                  if($image_name!=""){
                      //image selected
                      $ext = end(explode('.',$image_name));  //old image name would be first.jpg

                      $image_name = "Section".rand(0000,9999).".".$ext;   //new name will be "book name -890.jpg"

                      //upload the image-name
                      $src = $_FILES['image']['tmp_name'];

                      $dst = "../images/se/".$image_name;

                          //image move to our folder
                      $upload = move_uploaded_file($src, $dst);

                      if($upload==false){
                          $_SESSION['upload'] = "<div class='e'>not upload the image</div>";
                          header('location:'.SIT.'admin/add-ca.php');
                          die();
                      }
                      
                  }
         }else{
          $image_name="";
         }


        if(isset($_POST['fectured'])){
            $fectured = $_POST['fectured'];
        }else{
            $fectured = 'no';
        }

        if(isset($_POST['active'])){
            $active = $_POST['active'];
        }else{
            $active = 'no';
        }

        $sql = "INSERT INTO section SET
        name = '$name',
        image_name = '$image_name',
        fectured = '$fectured',
        active = '$active'
        ";
        
        $res = mysqli_query($conn, $sql);

        if($res==true){
            $_SESSION['add'] = "<div class='s'>uploaded successfully</div>";
            header("location:".SIT."admin/section.php");
        }else{
            $_SESSION['add'] = "<div class='f'>uploaded successfully</div>";
            header("location:".SIT."admin/section.php");

        }
    }
?>