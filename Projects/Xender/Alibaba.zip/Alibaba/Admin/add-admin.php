<?php include('../ad-par/menu.php');  ?> 

<section class="main">
<h1>Add Admin</h1><br>
    <form action="#" method='post'>
    
    <table class='tbl-30'>

    <tr>
        <td>Name:</td>
        <td><input type='text' name='name' placeholder='enter your Name'></td>
    </tr>

    <tr>
        <td>Username:</td>
        <td><input type='text' name='username' placeholder='enter your username'></td>
    </tr>

    <tr>
        <td>Password:</td>
        <td><input type='password' name='password'  placeholder='enter your password'></td>
    </tr>

    <tr>
        <td colspan='10px'><input type='submit' name='submit' value='add admin' class='btn-s'>
        </td>
    </tr>

    </table>
    </form>
</section>



<?php include('../ad-par/footer.php');  ?> 

<?php
        if(isset($_POST['submit'])){
            //get the data
            $name=$_POST['name'];
            $username=$_POST['username'];
            $password=md5($_POST['password']);

            //input data into the database
            $sql ="INSERT INTO admin SET
            name='$name',
            username='$username',
            password='$password'";

            //excuting the query
            $res = mysqli_query($conn, $sql) or die(mysqli_error());

            //check data is inserted or not
            if($res==true){
                $_SESSION['add']  ="<div class='s'>Admin added successfully</div>";
                header("location:".SIT."admin/admin.php");
            }

            else{
                $_SESSION['add'] = "<div class='f'>Admin added fail</div>";
                header("location:".SIT."admin/admin.php");
            }


        }

?>