<?php
    include("../Par/config.php");

    $id = $_GET['id'];

    $sql = "DELETE FROM section WHERE id='$id'";

    $res = mysqli_query($conn, $sql);

    if($res==true){
        $_SESSION['delete'] = "<div class='s'>Section deleted successfully</div>";
        header("location:".SIT."admin/section.php");
    }else{
        $_SESSION['delete'] = "<div class='f'>Section deleted failed</div>";
        header("location:".SIT."admin/section.php");
    }


?>