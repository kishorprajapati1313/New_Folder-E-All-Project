<?php 
include('../Par/config.php');

//get the id
$id = $_GET['id'];

//create sql query
$sql = "DELETE FROM admin WHERE id=$id";

$res= mysqli_query($conn, $sql);

if($res==true){
    $_SESSION['delete'] = "<div class='s'>deleted succesfully</div> ";
    header("location:".SIT."admin/admin.php");
}
else{
    $_SESSION['delete'] = "<div class='f'>deleted fail</div> ";
    header("location:".SIT."admin/admin.php");
}