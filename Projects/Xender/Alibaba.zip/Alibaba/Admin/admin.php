<?php include('../ad-par/menu.php');  ?> 

    
<section class="main">
<h1>Manage Admin</h1><br>
<?php
if(isset($_SESSION['add']))
        {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }

        if(isset($_SESSION['delete'])){
            echo $_SESSION['delete'];
            unset($_SESSION['delete']);
        }
        if(isset($_SESSION['update'])){
            echo $_SESSION['update'];
            unset($_SESSION['update']);
        }
        if(isset($_SESSION['c_p'])){
            echo $_SESSION['c_p'];
            unset($_SESSION['c_p']);
        }
        if(isset($_SESSION['p_m'])){
            echo $_SESSION['p_m'];
            unset($_SESSION['p_m']);
        }
        if(isset($_SESSION['u_f'])){
            echo $_SESSION['u_f'];
            unset($_SESSION['u_f']);
        }
       
?><br><br>
    <a href="add-admin.php" class='btn-p'>Add admin</a><br><br><br><br>
    <table class="tbl">
            <tr>
                <th>S.N</th>
                <th>Full-Name</th>
                <th>Username</th>
                <th>Action</th>
            </tr>

                <?php
                $sql = "SELECT * FROM admin ";
                $res = mysqli_query($conn, $sql);

                if($res==true){
                    $count = mysqli_num_rows($res);
                    $sn=1;
                    if($count>0){
                        while($row=mysqli_fetch_assoc($res)){
                            $id = $row['id'];
                            $name = $row['name'];
                            $username = $row['username'];
                            ?>
                            <tr>
                            <td><?php echo $sn++; ?></td>
                            <td><?php echo $name; ?></td>
                            <td><?php echo $username; ?></td>
                            <td>
                                <a href='<?php echo SIT; ?>admin/admin-cp.php?id=<?php echo $id; ?>' class='btn'>change password</a>
                                <a href="<?php echo SIT; ?>admin/admin-update.php?id=<?php echo $id; ?>" class="btn-s ">Update Admin</a>
                                <a href="<?php echo SIT; ?>admin/admin-delete.php?id=<?php echo $id; ?> " class="btn-d"> Delete Admin</a>
                            </td>
                        </tr>
                        <?php
                        }
                    }
                }

?>

     
</table>
</section>



<?php include('../ad-par/footer.php');  ?> 